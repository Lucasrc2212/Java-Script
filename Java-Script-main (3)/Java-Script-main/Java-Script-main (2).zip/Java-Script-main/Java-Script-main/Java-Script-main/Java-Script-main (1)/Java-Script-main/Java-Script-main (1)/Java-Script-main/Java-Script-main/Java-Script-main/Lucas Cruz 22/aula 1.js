a = 1
b = 2

alert(a + b);

document.write(a>b);
document.write(a==b);
document.write(a!=b);